duband
======
duband1.0

对应的公版版本为 duband1.0

官方网站：http://dulife.baidu.com/

联系方式：device-dev@baidu.com

手把手教你做手环的教程链接：http://yuedu.baidu.com/ebook/6015724f0b4e767f5acfceb7.html
