# ProjectRTC

The signaling part is done with [socket.io](socket.io).
The client follows a MVVM pattern [knockoutjs](http://knockoutjs.com/)

## Install

It requires [node.js](http://nodejs.org/download/)

* git clone https://github.com/pchab/ProjectRTC.git
* cd ProjectRTC/
* npm install
* npm start

The server will run on port 3000.
You can test it in the (Chrome) browser at localhost:3000.
